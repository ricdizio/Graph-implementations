/**
 *
 */

public class Arista extends Lado
{
  private Vertice u;
  private Vertice v;
  
  public Arista(String id, double peso, Vertice u, Vertice v) {
  }

  public Vertice getExtremo1() {
  }

  public Vertice getExtremo2() {
  }

  public String toString() {
  }
}