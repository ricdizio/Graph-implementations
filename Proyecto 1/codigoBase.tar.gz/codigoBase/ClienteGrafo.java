/**
 *
 */

import java.util.*;

public class ClienteGrafo {
  public static void main(String [] args) {

  }
}