/**
 * 
 */

public class Vertice
{
  private String id;
  private double peso;
  
  public Vertice(String id, double peso) {
  }

  public double getPeso() {
  }

  public String getId() {
  }

  public String toString() { 
  }
}