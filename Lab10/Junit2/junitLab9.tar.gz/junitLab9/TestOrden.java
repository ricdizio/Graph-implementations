import junit.framework.TestCase;
import java.io.IOException;

public class TestOrden extends TestCase {

    public void testOrden1()
    { 
      Verificador.Grafo g  = new Verificador.Grafo("dependencias.txt");
      String[] results = AbstractMainTests.executeMain("Orden", new String[]{"dependencias.txt"});
      String result = "";
      for (int i = 0; i < results.length; i++)
        result += results[i];
      boolean expected = g.validate (result);
      assertTrue ("fallo prueba 1", expected);
    }
}
